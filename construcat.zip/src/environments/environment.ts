export const environment = {

    apiUrl:""
};
