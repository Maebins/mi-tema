import { computed, Injectable, signal } from '@angular/core';
import { AppMenuItem } from '../menu/menu.models';

@Injectable({
    providedIn: 'root',
})
export class LayoutService {
    private _isDesktopCollapsed = signal<boolean>(true);
    isDesktopCollapsed = this._isDesktopCollapsed.asReadonly();

    private _isMobileOpen = signal<boolean>(false);
    isMobileOpen = this._isMobileOpen.asReadonly();

    isMiniMode = computed(() => this._isDesktopCollapsed() && window.innerWidth >= 768); // 1024px es 'lg' en Tailwind

    constructor() {}

    toggleDesktopSidebar() {
        this._isDesktopCollapsed.update((state) => !state);
    }

    toggleMobileSidebar() {
        this._isMobileOpen.update((state) => !state);
    }

    closeMobileSidebar() {
        this._isMobileOpen.set(false);
    }

    getMenu(): AppMenuItem[] {
        return [
            // --- GRUPO 1 ---
            { 
                type: 'group', 
                label: 'FUNDAMENTOS', 
                children: [
                    { type: 'basic', label: 'Paleta de colores', icon: 'colors', routerLink: ['/paleta'] },
                    { type: 'basic', label: 'Tipografia', icon: 'text_format', routerLink: ['/tipografia'] },
                ]
            },

            // --- DIVISOR Y GRUPO 2 ---
            { type: 'divider' }, 
            { 
                type: 'group', 
                label: 'UI ELEMENTS', 
                children: [
                    { type: 'basic', label: 'Botones', icon: 'buttons_alt', routerLink: ['/botones-estados'] },
                    { type: 'basic', label: 'Formularios', icon: 'ballot', routerLink: ['/formularios'] },
                ]
            },

            // --- DIVISOR Y GRUPO 3 ---
            { type: 'divider' },
            { 
                type: 'group', 
                label: ' TABLAS & NAVEGACION', 
                children: [
                    { type: 'basic', label: 'Tables', icon: 'table_chart', routerLink: ['/tablas'] },
                    { type: 'basic', label: 'Navegación', icon: 'side_navigation', routerLink: ['/navegacion'] },
                    
                ]
            }
        ];
    }
}
