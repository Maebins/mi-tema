import { Component } from '@angular/core';

@Component({
  selector: 'app-tipografia',
  imports: [],
  templateUrl: './tipografia.component.html',
  styleUrl: './tipografia.component.scss',
})
export class TipografiaComponent {

}
