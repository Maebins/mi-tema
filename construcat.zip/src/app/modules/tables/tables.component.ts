import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { TableComponent } from '../../shared/components/table/table.component';
import { TableColumn } from '../../shared/components/table/table.types';

@Component({
  selector: 'app-tables',
  imports: [CommonModule, TableComponent],
  templateUrl: './tables.component.html',
  styleUrl: './tables.component.scss',
  standalone: true
})
export class TablesComponent {
   // 1. Definición de todas las columnas posibles
      public columnas: TableColumn[] = [
          { header: 'ID', field: 'id', width: '60px' },
          { header: 'Nombre del equipo', field: 'nombre', editable: true }, // Celda editable
          { header: 'Fecha Registro', field: 'fecha', type: 'date', width: '180px' }, // Tipo fecha
          { header: 'Ubicación', field: 'ubicacion' },
      ];
  
      // 2. Opciones para la columna de selección rápida
      public opcionesPrioridad = [
          { label: 'Alta', value: 'H' },
          { label: 'Media', value: 'M' },
          { label: 'Baja', value: 'L' }
      ];
  
      // 3. Datos de prueba con diferentes estados
      public datos = [
          { 
              id: 1, nombre: 'Laptop Dell Latitude', fecha: new Date(), ubicacion: 'Oficina 101',
              prioridad: 'H', checked: true, 
              estadoLabel: 'Activo', estadoType: 'success' // Chip verde
          },
          { 
              id: 2, nombre: 'Escritorio Madera', fecha: new Date(), ubicacion: 'Almacén',
              prioridad: 'M', checked: false, 
              estadoLabel: 'Inactivo', estadoType: 'warning' // Chip naranja
          },
          { 
              id: 3, nombre: 'Proyector Epson', fecha: new Date(), ubicacion: 'Sala Reuniones',
              prioridad: 'L', checked: true, 
              estadoLabel: 'Dado de Baja', estadoType: 'danger' // Chip rojo
          }
      ];
  
      // 4. Handlers para todos los eventos
      handleAction(type: string, row: any) {
          console.log(`Acción: ${type}`, row);
      }
  
      onCellEdit(event: any) {
          console.log('Celda editada:', event);
      }
      modoAuditoria= false
}
