import { Component } from '@angular/core';

@Component({
  selector: 'app-paleta',
  imports: [],
  templateUrl: './paleta.component.html',
  styleUrl: './paleta.component.scss',
})
export class PaletaComponent {

}
