import { Component } from '@angular/core';
import { FormFieldComponent } from '../../shared/components/form-field/form-field.component';
import { CustomFormField } from '../../shared/components/form-field/form-field.types';
import { DatePickerComponent } from '../../shared/components/date-picker/date-picker.component';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-formularios',
  imports: [FormFieldComponent, DatePickerComponent, CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './formularios.component.html',
  styleUrl: './formularios.component.scss',
  standalone: true
})
export class FormulariosComponent {
   // Opciones de prueba para los selects
    opcionesEstado = [
      { label: 'Bueno', value: 'B' },
      { label: 'Regular', value: 'R' },
      { label: 'Malo', value: 'M' }
    ];
  
    opcionesPersonal = [
      { label: 'Juan Perez', value: 1 },
      { label: 'Maria Lopez', value: 2 },
      { label: 'Carlos Ruiz', value: 3 }
    ];
  
    // 1. TEXTO NORMAL[cite: 3, 5]
    configText: CustomFormField = {
      type: 'text',
      label: 'Código',
      placeholder: 'Ej. 740893320001',
      required: true,
      inputTooltip: 'Ingrese el código de 12 dígitos'
    };
  
    // 2. TEXTAREA[cite: 3, 5]
    configTextarea: CustomFormField = {
      type: 'textarea',
      label: 'Descripción',
      placeholder: 'Detalle las características físicas...',
      maxLength: 250
    };
  
    // 3. SELECT LABEL (Guarda el label en vez del value)[cite: 3, 5]
    configSelectLabel: CustomFormField = {
      type: 'selectLabel',
      label: 'Condición (Select Label)',
      options: this.opcionesEstado,
      placeholder: 'Seleccione condición'
    };
  
    // 4. SELECT VALUE (El select estándar)[cite: 3, 5]
    configSelectValue: CustomFormField = {
      type: 'selectValue',
      label: 'Estado de Conservación (Select Value)',
      options: this.opcionesEstado,
      placeholder: 'Seleccione estado',
      tooltipOnHover: true
    };
  
    // 5. SELECT INPUT (Permite escribir o seleccionar)[cite: 3, 5]
    configSelectInput: CustomFormField = {
      type: 'selectInput',
      label: 'Marca (Select Input Editable)',
      options: [
        { label: 'HP', value: 'HP' },
        { label: 'Lenovo', value: 'LEN' },
        { label: 'Dell', value: 'DEL' }
      ],
      placeholder: 'Escriba o seleccione una marca'
    };
  
    // 6. SELECT FILTER (Dropdown con buscador interno)[cite: 3, 5]
    configSelectFilter: CustomFormField = {
      type: 'selectFilter',
      label: 'Responsable (Select Filter)',
      options: this.opcionesPersonal,
      placeholder: 'Buscar responsable...'
    };
  
    valorDni: string = '';
  
    // 7. SELECT MULTIPLE (Con tags/chips)[cite: 3, 5]
    configSelectMultiple: CustomFormField = {
      type: 'selectMultiple',
      label: 'Accesorios Incluidos (Select Multiple)',
      options: [
        { label: 'Teclado', value: 'TEC' },
        { label: 'Mouse', value: 'MOU' },
        { label: 'Monitor', value: 'MON' },
        { label: 'Cables', value: 'CAB' }
      ],
      placeholder: 'Seleccione múltiples'
    };
  
    configError: CustomFormField = {
    type: 'text',
    label: 'Número de DNI',
    placeholder: 'Ingrese 8 dígitos',
    required: true,
    maxLength: 8,
    // Estos mensajes son los que se mostrarán debajo del input
    errorMessages: {
      required: 'Este campo es obligatorio para el registro.',
      minlength: 'El DNI debe tener exactamente 8 dígitos.'
    }
  };

  // Variables para almacenar las fechas
  fechaSimple: Date | null = null;
  fechaYHora: Date | null = null;
  soloHora: Date | null = null;

  // Fecha mínima (Ejemplo: Hoy)
  fechaMinima = new Date();
  

}
