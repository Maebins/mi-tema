import { Component } from '@angular/core';
import { ButtonComponent } from '../../shared/components/button/button.component';

@Component({
  selector: 'app-botones',
  imports: [ButtonComponent],
  templateUrl: './botones.component.html',
  styleUrl: './botones.component.scss',
  standalone: true
})
export class BotonesComponent {

}
