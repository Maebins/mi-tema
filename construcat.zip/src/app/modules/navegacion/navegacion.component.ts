import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { PermissionStepperComponent } from '../../shared/components/permission-stepper/permission-stepper.component';
import { CardComponent } from '../../shared/components/card/card.component';
import { ButtonComponent } from '../../shared/components/button/button.component';
import { TabsComponent } from '../../shared/components/tabs/tabs.component';
import { StepperComponent } from '../../shared/components/stepper/stepper.component';

@Component({
  selector: 'app-navegacion',
  standalone: true,
  imports: [CommonModule, PermissionStepperComponent, TabsComponent, StepperComponent],
  templateUrl: './navegacion.component.html',
  styleUrl: './navegacion.component.scss',
})
export class NavegacionComponent {
  // Tu configuración exacta de Tabs
    pestanas = [
        { id: 'registro', label: 'Registro de Bien', icon: 'pi pi-plus-circle' },
        { id: 'adjuntos', label: 'Galería y Fotos', icon: 'pi pi-images' },
        { id: 'alertas', label: 'Centro de Avisos', icon: 'pi pi-bell' }
    ];
    pestanaActiva = 'registro';

    
    misPasos = [
        { label: 'Datos personales' },
        { label: 'Documentos' },
        { label: 'Verificación' },
        { label: 'Confirmación' }
    ];

    pasoActual = 3; // Esto iluminará el paso 3 y pondrá checks en el 1 y 2

    // Función para cambiar de paso
    irAlPaso(paso: number) {
        this.pasoActual = paso;
    }

}
