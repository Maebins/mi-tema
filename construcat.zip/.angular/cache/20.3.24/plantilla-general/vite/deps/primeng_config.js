import {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
} from "./chunk-RKH4RENK.js";
import "./chunk-AL25OPUS.js";
import "./chunk-OFPMW2ER.js";
import "./chunk-UNA66MSA.js";
import "./chunk-FZNNPS64.js";
import "./chunk-U44TYWUZ.js";
import "./chunk-LVESTRRP.js";
import "./chunk-RSS3ODKE.js";
import "./chunk-WDMUDEB6.js";
export {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
};
